from bluepy import btle
from gpiozero import Button

DEVICE_MAC = "F4:12:FA:9F:30:05"  # Replace with your Arduino's MAC
SERVICE_UUID = "180C"
CHAR_UUID = "2A56"
running = True
message = ""
sent = True

up = Button(17)
down = Button(27)
left = Button(22)
right = Button(23)
rst = Button(24)

def typemess():
    global sent
    global running
    if  sent and running:
        """
        if up.wait_for_press():
            message = "SUS"
            characteristic.write(message.encode(), withResponse=True)
        if down.wait_for_press():
            message = "JOS"
            characteristic.write(message.encode(), withResponse=True)
        if left.wait_for_press():
            message = "STANGA"
            characteristic.write(message.encode(), withResponse=True)
        if right.wait_for_press():
            message = "DREAPTA"
            characteristic.write(message.encode(), withResponse=True)
        if rst.wait_for_press():
            message = "RESET"
            characteristic.write(message.encode(), withResponse=True)
            """
        for x in range(100):
            message = str(x)
            characteristic.write(message.encode(), withResponse=True)
                
        sent = False
        if message == "RESET":
            print("Disconnected.")
            running = False
            peripheral.disconnect()
           
try:
    print("Connecting to Arduino...")
    peripheral = btle.Peripheral(DEVICE_MAC)
    service = peripheral.getServiceByUUID(SERVICE_UUID)
    characteristic = service.getCharacteristics(CHAR_UUID)[0]
    print("Sending data...")
    while running:
        sent = True
        typemess()
        

except Exception as e:
    print(f"Error: {e}")
